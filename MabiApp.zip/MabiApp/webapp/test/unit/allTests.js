sap.ui.define([
	"demo/MacbiApp/test/unit/controller/App.controller"
], function () {
	"use strict";
});