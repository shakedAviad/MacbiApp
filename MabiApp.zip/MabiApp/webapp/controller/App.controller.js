sap.ui.define([
	"./BaseController",
		"sap/m/MessageToast"
], function (Controller,MessageToast) {
	"use strict";

	return Controller.extend("demo.MacbiApp.controller.App", {
		onInit: function () {}

	});
});