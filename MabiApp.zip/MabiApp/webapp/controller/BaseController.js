sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/BusyIndicator"
], function (Controller, BusyIndicator) {
	"use strict";

	return Controller.extend("demo.MacbiApp.controller.BaseController", {
		_oBoundle: null,

		getText: function (sPorperty) {
			if (!this._oBoundle)
				this._oBoundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();

			return this._oBoundle.getText(sPorperty);
		},
		openDialog: function (sId, Path) {
			var oView = this.getView();
			var oDialog = oView.byId(sId);
			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(oView.getId(), Path, this);
				oView.addDependent(oDialog);
			}
			oDialog.open();

		},

		/**
		 * @input sId-Dialog ID
		 * return Close Popup Dialog
		 */
		onCloseDialog: function (sId) {
			this.byId(sId).close();
		}
		

	});
});